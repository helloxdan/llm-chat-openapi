# llm-chat-openapi
chat api  collection for popular LLM

## run 
python main.py
## package
python setup.py sdist
